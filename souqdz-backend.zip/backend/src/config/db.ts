import { PrismaClient } from "@prisma/client";

// On garde une seule instance de PrismaClient dans toute l'application
// (évite d'ouvrir trop de connexions à la base de données)
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
});

export default prisma;
