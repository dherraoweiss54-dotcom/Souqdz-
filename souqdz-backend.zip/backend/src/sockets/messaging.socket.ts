import { Server as HttpServer } from "http";
import { Server, Socket } from "socket.io";
import { verifyToken } from "../utils/jwt";
import { env } from "../config/env";
import prisma from "../config/db";
import { createNotification } from "../services/notification.service";

interface AuthedSocket extends Socket {
  userId?: string;
}

export function initSocket(httpServer: HttpServer) {
  const io = new Server(httpServer, {
    cors: { origin: env.frontendUrl, credentials: true },
  });

  // Authentification du socket via le token JWT envoyé par le client
  io.use((socket: AuthedSocket, next) => {
    try {
      const token = socket.handshake.auth?.token as string | undefined;
      if (!token) return next(new Error("Non authentifié."));
      const payload = verifyToken(token);
      socket.userId = payload.userId;
      next();
    } catch {
      next(new Error("Token invalide."));
    }
  });

  io.on("connection", (socket: AuthedSocket) => {
    console.log(`🔌 Socket connecté: ${socket.userId}`);

    // L'utilisateur rejoint une "room" personnelle pour recevoir ses notifications
    if (socket.userId) socket.join(`user:${socket.userId}`);

    // Rejoindre une conversation précise
    socket.on("join_conversation", async (conversationId: string) => {
      const conv = await prisma.conversation.findUnique({ where: { id: conversationId } });
      if (!conv || (conv.buyerId !== socket.userId && conv.sellerId !== socket.userId)) {
        return; // accès refusé silencieusement
      }
      socket.join(`conversation:${conversationId}`);
    });

    // Envoi d'un message
    socket.on("send_message", async (data: { conversationId: string; contenu: string }) => {
      try {
        const { conversationId, contenu } = data;
        if (!contenu?.trim()) return;

        const conv = await prisma.conversation.findUnique({ where: { id: conversationId } });
        if (!conv || (conv.buyerId !== socket.userId && conv.sellerId !== socket.userId)) {
          return socket.emit("error_message", "Accès refusé à cette conversation.");
        }

        const message = await prisma.message.create({
          data: {
            conversationId,
            senderId: socket.userId!,
            contenu: contenu.trim(),
          },
        });

        // Diffuser le message à tous les membres de la conversation
        io.to(`conversation:${conversationId}`).emit("new_message", message);

        // Notifier le destinataire (utile s'il n'est pas en train de regarder la conversation)
        const recipientId = conv.buyerId === socket.userId ? conv.sellerId : conv.buyerId;
        await createNotification(recipientId, "NOUVEAU_MESSAGE", "Tu as reçu un nouveau message.");
        io.to(`user:${recipientId}`).emit("notification", {
          type: "NOUVEAU_MESSAGE",
          contenu: "Tu as reçu un nouveau message.",
        });
      } catch (err) {
        console.error("Erreur send_message:", err);
        socket.emit("error_message", "Erreur lors de l'envoi du message.");
      }
    });

    // Indicateur "en train d'écrire"
    socket.on("typing", (conversationId: string) => {
      socket.to(`conversation:${conversationId}`).emit("typing", { userId: socket.userId });
    });

    socket.on("disconnect", () => {
      console.log(`🔌 Socket déconnecté: ${socket.userId}`);
    });
  });

  return io;
}
