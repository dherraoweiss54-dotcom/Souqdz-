import http from "http";
import app from "./app";
import { env } from "./config/env";
import { initSocket } from "./sockets/messaging.socket";

const server = http.createServer(app);

// Messagerie temps réel (Socket.io)
initSocket(server);

server.listen(env.port, () => {
  console.log(`🚀 SouqDZ API démarrée sur http://localhost:${env.port}`);
  console.log(`   Environnement: ${env.nodeEnv}`);
});
