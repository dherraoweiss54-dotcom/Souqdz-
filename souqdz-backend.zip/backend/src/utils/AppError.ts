// Classe d'erreur personnalisée : permet de renvoyer un code HTTP précis
// et un message clair au frontend, au lieu d'un crash générique 500.
export class AppError extends Error {
  statusCode: number;

  constructor(message: string, statusCode: number = 400) {
    super(message);
    this.statusCode = statusCode;
    Object.setPrototypeOf(this, AppError.prototype);
  }
}
