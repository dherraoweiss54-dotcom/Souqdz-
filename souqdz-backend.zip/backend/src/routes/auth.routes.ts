import { Router } from "express";
import { body } from "express-validator";
import * as authController from "../controllers/auth.controller";
import { validate } from "../middleware/validate.middleware";
import { requireAuth } from "../middleware/auth.middleware";

const router = Router();

const registerRules = [
  body("prenom").trim().notEmpty().withMessage("Le prénom est requis."),
  body("nom").trim().notEmpty().withMessage("Le nom est requis."),
  body("email").isEmail().withMessage("Email invalide."),
  body("telephone")
    .matches(/^0[5-7][0-9]{8}$/)
    .withMessage("Numéro de téléphone algérien invalide (ex: 0551234567)."),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Le mot de passe doit contenir au moins 6 caractères."),
  body("wilaya").trim().notEmpty().withMessage("La wilaya est requise."),
  body("commune").trim().notEmpty().withMessage("La commune est requise."),
];

const loginRules = [
  body("email").isEmail().withMessage("Email invalide."),
  body("password").notEmpty().withMessage("Le mot de passe est requis."),
];

router.post("/register", registerRules, validate, authController.register);
router.post("/login", loginRules, validate, authController.login);
router.get("/me", requireAuth, authController.me);
router.post("/become-seller", requireAuth, authController.becomeSeller);

export default router;
