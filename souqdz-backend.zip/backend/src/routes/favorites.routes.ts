import { Router } from "express";
import * as favoritesController from "../controllers/favorites.controller";
import { requireAuth } from "../middleware/auth.middleware";

const router = Router();

router.use(requireAuth);

router.get("/", favoritesController.myFavorites);
router.post("/:productId", favoritesController.addFavorite);
router.delete("/:productId", favoritesController.removeFavorite);

export default router;
