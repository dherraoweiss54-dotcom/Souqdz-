import { Router } from "express";
import { body } from "express-validator";
import * as productsController from "../controllers/products.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { uploadProductImages } from "../middleware/upload.middleware";
import { validate } from "../middleware/validate.middleware";

const router = Router();

// Routes publiques
router.get("/", productsController.listProducts);

// Routes vendeur (AVANT /:id pour ne pas être interceptées par le paramètre dynamique)
router.get("/mine/list", requireAuth, requireRole("SELLER", "ADMIN"), productsController.myProducts);
router.get("/mine/stats", requireAuth, requireRole("SELLER", "ADMIN"), productsController.sellerStats);

router.get("/:id", productsController.getProductById);

const productRules = [
  body("nom").trim().notEmpty().withMessage("Le nom du produit est requis."),
  body("description").trim().notEmpty().withMessage("La description est requise."),
  body("prix").isFloat({ gt: 0 }).withMessage("Le prix doit être un nombre positif."),
  body("categoryId").notEmpty().withMessage("La catégorie est requise."),
  body("etat").isIn(["NEUF", "OCCASION"]).withMessage("État invalide."),
  body("wilaya").trim().notEmpty().withMessage("La wilaya est requise."),
  body("commune").trim().notEmpty().withMessage("La commune est requise."),
  body("livraison")
    .isIn(["LIVRAISON", "MAIN_PROPRE", "LES_DEUX"])
    .withMessage("Mode de livraison invalide."),
];

router.post(
  "/",
  requireAuth,
  requireRole("SELLER", "ADMIN"),
  uploadProductImages,
  productRules,
  validate,
  productsController.createProduct
);

router.put(
  "/:id",
  requireAuth,
  requireRole("SELLER", "ADMIN"),
  productsController.updateProduct
);

router.patch(
  "/:id/status",
  requireAuth,
  requireRole("SELLER", "ADMIN"),
  productsController.updateProductStatus
);

router.delete("/:id", requireAuth, requireRole("SELLER", "ADMIN"), productsController.deleteProduct);

export default router;
