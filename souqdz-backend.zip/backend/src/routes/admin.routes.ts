import { Router } from "express";
import * as adminController from "../controllers/admin.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";

const router = Router();
router.use(requireAuth, requireRole("ADMIN"));

router.get("/dashboard", adminController.dashboard);

router.get("/users", adminController.listUsers);
router.get("/users/:id", adminController.getUserDetail);
router.patch("/users/:id/suspend", adminController.suspendUser);
router.patch("/users/:id/reactivate", adminController.reactivateUser);
router.delete("/users/:id", adminController.deleteUser);

router.get("/products", adminController.listProductsAdmin);
router.patch("/products/:id/approve", adminController.approveProduct);
router.patch("/products/:id/reject", adminController.rejectProduct);
router.patch("/products/:id/suspend", adminController.suspendProductAdmin);
router.delete("/products/:id", adminController.deleteProductAdmin);

export default router;
