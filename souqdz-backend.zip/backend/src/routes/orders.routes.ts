import { Router } from "express";
import { body } from "express-validator";
import * as ordersController from "../controllers/orders.controller";
import { requireAuth } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";

const router = Router();
router.use(requireAuth);

const createOrderRules = [
  body("productId").notEmpty().withMessage("Le produit est requis."),
  body("nomAcheteur").trim().notEmpty().withMessage("Le nom est requis."),
  body("telephone")
    .matches(/^0[5-7][0-9]{8}$/)
    .withMessage("Numéro de téléphone algérien invalide."),
  body("wilaya").trim().notEmpty().withMessage("La wilaya est requise."),
  body("commune").trim().notEmpty().withMessage("La commune est requise."),
  body("adresse").trim().notEmpty().withMessage("L'adresse est requise."),
  body("modeLivraison")
    .isIn(["LIVRAISON", "MAIN_PROPRE", "LES_DEUX"])
    .withMessage("Mode de livraison invalide."),
];

router.post("/", createOrderRules, validate, ordersController.createOrder);
router.get("/mine", ordersController.myOrdersAsBuyer);
router.get("/received", ordersController.receivedOrders);
router.patch("/:id/status", ordersController.updateOrderStatus);

export default router;
