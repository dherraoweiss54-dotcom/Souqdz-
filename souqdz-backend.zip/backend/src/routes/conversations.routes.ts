import { Router } from "express";
import * as conversationsController from "../controllers/conversations.controller";
import { requireAuth } from "../middleware/auth.middleware";

const router = Router();
router.use(requireAuth);

router.post("/start", conversationsController.startConversation);
router.get("/", conversationsController.myConversations);
router.get("/:id/messages", conversationsController.getMessages);

export default router;
