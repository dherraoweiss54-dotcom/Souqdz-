import { Router } from "express";
import * as reportsController from "../controllers/reports.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";

const router = Router();
router.use(requireAuth);

// N'importe quel utilisateur connecté peut signaler
router.post("/", reportsController.createReport);

// Réservé à l'admin
router.get("/", requireRole("ADMIN"), reportsController.listReports);
router.patch("/:id", requireRole("ADMIN"), reportsController.updateReportStatus);

export default router;
