import { Router } from "express";
import { WILAYAS } from "../utils/wilayas";

const router = Router();

router.get("/wilayas", (req, res) => {
  res.status(200).json({ success: true, data: WILAYAS });
});

export default router;
