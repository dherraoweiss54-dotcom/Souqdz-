import prisma from "../config/db";

export async function logAdminAction(
  adminId: string,
  action: string,
  targetType: string,
  targetId: string
) {
  return prisma.adminAction.create({
    data: { adminId, action, targetType, targetId },
  });
}
