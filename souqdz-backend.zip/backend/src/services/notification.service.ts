import prisma from "../config/db";

export type NotificationType =
  | "NOUVEAU_MESSAGE"
  | "COMMANDE_ACCEPTEE"
  | "COMMANDE_REFUSEE"
  | "COMMANDE_STATUT"
  | "PRODUIT_APPROUVE"
  | "PRODUIT_REFUSE"
  | "NOUVELLE_COMMANDE";

export async function createNotification(
  userId: string,
  type: NotificationType,
  contenu: string
) {
  return prisma.notification.create({
    data: { userId, type, contenu },
  });
}
