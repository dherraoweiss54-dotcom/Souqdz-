import { Request, Response } from "express";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";

// POST /api/favorites/:productId
export const addFavorite = asyncHandler(async (req: Request, res: Response) => {
  const { productId } = req.params;
  const userId = req.user!.userId;

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new AppError("Produit introuvable.", 404);

  const existing = await prisma.favorite.findUnique({
    where: { userId_productId: { userId, productId } },
  });
  if (existing) {
    return res.status(200).json({ success: true, message: "Déjà dans tes favoris." });
  }

  await prisma.favorite.create({ data: { userId, productId } });
  res.status(201).json({ success: true, message: "Ajouté aux favoris." });
});

// DELETE /api/favorites/:productId
export const removeFavorite = asyncHandler(async (req: Request, res: Response) => {
  const { productId } = req.params;
  const userId = req.user!.userId;

  await prisma.favorite.deleteMany({ where: { userId, productId } });
  res.status(200).json({ success: true, message: "Retiré des favoris." });
});

// GET /api/favorites  (mes favoris)
export const myFavorites = asyncHandler(async (req: Request, res: Response) => {
  const favorites = await prisma.favorite.findMany({
    where: { userId: req.user!.userId },
    orderBy: { createdAt: "desc" },
    include: {
      product: {
        include: {
          images: { take: 1, orderBy: { ordre: "asc" } },
          seller: { select: { prenom: true, nom: true } },
        },
      },
    },
  });

  res.status(200).json({ success: true, data: favorites.map((f) => f.product) });
});
