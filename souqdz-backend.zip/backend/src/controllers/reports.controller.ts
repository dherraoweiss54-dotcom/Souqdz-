import { Request, Response } from "express";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";

const MOTIFS = [
  "PRODUIT_INTERDIT",
  "ARNAQUE",
  "FAUX_PRODUIT",
  "MAUVAISE_DESCRIPTION",
  "PRIX_INCORRECT",
  "CONTENU_OFFENSANT",
  "AUTRE",
];

// ==========================================
// POST /api/reports  (n'importe quel utilisateur connecté signale un produit)
// ==========================================
export const createReport = asyncHandler(async (req: Request, res: Response) => {
  const { productId, motif, description } = req.body;

  if (!productId || !motif) {
    throw new AppError("Le produit et le motif sont obligatoires.", 422);
  }
  if (!MOTIFS.includes(motif)) {
    throw new AppError("Motif de signalement invalide.", 422);
  }

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new AppError("Produit introuvable.", 404);

  const report = await prisma.report.create({
    data: {
      productId,
      reporterId: req.user!.userId,
      motif,
      description,
    },
  });

  res.status(201).json({
    success: true,
    message: "Merci, ton signalement a été envoyé à l'équipe SouqDZ.",
    data: report,
  });
});

// ==========================================
// GET /api/reports  (ADMIN uniquement)
// ==========================================
export const listReports = asyncHandler(async (req: Request, res: Response) => {
  const { status } = req.query as { status?: string };

  const reports = await prisma.report.findMany({
    where: status ? { status: status as any } : undefined,
    orderBy: { createdAt: "desc" },
    include: {
      product: { select: { id: true, nom: true, status: true } },
      reporter: { select: { id: true, prenom: true, nom: true } },
    },
  });

  res.status(200).json({ success: true, data: reports });
});

// ==========================================
// PATCH /api/reports/:id  (ADMIN uniquement — changer le statut)
// ==========================================
export const updateReportStatus = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body; // NOUVEAU | EN_COURS | RESOLU

  if (!["NOUVEAU", "EN_COURS", "RESOLU"].includes(status)) {
    throw new AppError("Statut invalide.", 422);
  }

  const report = await prisma.report.update({ where: { id }, data: { status } });

  res.status(200).json({ success: true, data: report });
});
