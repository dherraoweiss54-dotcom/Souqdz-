import { Request, Response } from "express";
import prisma from "../config/db";
import { asyncHandler } from "../middleware/error.middleware";

// GET /api/notifications
export const myNotifications = asyncHandler(async (req: Request, res: Response) => {
  const notifications = await prisma.notification.findMany({
    where: { userId: req.user!.userId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  const unreadCount = await prisma.notification.count({
    where: { userId: req.user!.userId, isRead: false },
  });

  res.status(200).json({ success: true, data: notifications, unreadCount });
});

// PATCH /api/notifications/:id/read
export const markAsRead = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  await prisma.notification.updateMany({
    where: { id, userId: req.user!.userId },
    data: { isRead: true },
  });
  res.status(200).json({ success: true });
});

// PATCH /api/notifications/read-all
export const markAllAsRead = asyncHandler(async (req: Request, res: Response) => {
  await prisma.notification.updateMany({
    where: { userId: req.user!.userId, isRead: false },
    data: { isRead: true },
  });
  res.status(200).json({ success: true });
});
