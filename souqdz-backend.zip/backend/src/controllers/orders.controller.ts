import { Request, Response } from "express";
import { Prisma } from "@prisma/client";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";
import { createNotification } from "../services/notification.service";

// ==========================================
// POST /api/orders  (acheteur confirme une commande)
// ==========================================
export const createOrder = asyncHandler(async (req: Request, res: Response) => {
  const {
    productId,
    quantite = 1,
    nomAcheteur,
    telephone,
    wilaya,
    commune,
    adresse,
    modeLivraison,
  } = req.body;

  if (!productId || !nomAcheteur || !telephone || !wilaya || !commune || !adresse || !modeLivraison) {
    throw new AppError("Tous les champs de la commande sont obligatoires.", 422);
  }

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new AppError("Produit introuvable.", 404);
  if (product.status !== "ACTIVE") {
    throw new AppError("Ce produit n'est plus disponible à la commande.", 400);
  }
  if (product.sellerId === req.user!.userId) {
    throw new AppError("Tu ne peux pas commander ton propre produit.", 400);
  }

  const prixTotal = product.prix.mul(new Prisma.Decimal(quantite));

  const order = await prisma.order.create({
    data: {
      buyerId: req.user!.userId,
      sellerId: product.sellerId,
      productId,
      quantite,
      prixTotal,
      nomAcheteur,
      telephone,
      wilaya,
      commune,
      adresse,
      modeLivraison,
      status: "EN_ATTENTE",
    },
    include: { product: { select: { nom: true } } },
  });

  await createNotification(
    product.sellerId,
    "NOUVELLE_COMMANDE",
    `Nouvelle commande pour "${product.nom}".`
  );

  res.status(201).json({ success: true, message: "Commande confirmée.", data: order });
});

// ==========================================
// GET /api/orders/mine  (mes commandes en tant qu'acheteur)
// ==========================================
export const myOrdersAsBuyer = asyncHandler(async (req: Request, res: Response) => {
  const orders = await prisma.order.findMany({
    where: { buyerId: req.user!.userId },
    orderBy: { createdAt: "desc" },
    include: {
      product: { include: { images: { take: 1, orderBy: { ordre: "asc" } } } },
      seller: { select: { prenom: true, nom: true } },
    },
  });
  res.status(200).json({ success: true, data: orders });
});

// ==========================================
// GET /api/orders/received  (commandes reçues en tant que vendeur)
// ==========================================
export const receivedOrders = asyncHandler(async (req: Request, res: Response) => {
  const orders = await prisma.order.findMany({
    where: { sellerId: req.user!.userId },
    orderBy: { createdAt: "desc" },
    include: {
      product: { include: { images: { take: 1, orderBy: { ordre: "asc" } } } },
      buyer: { select: { prenom: true, nom: true } },
    },
  });
  res.status(200).json({ success: true, data: orders });
});

// ==========================================
// PATCH /api/orders/:id/status  (le vendeur fait avancer la commande)
// ==========================================
const VALID_STATUSES = [
  "ACCEPTEE",
  "REFUSEE",
  "EN_PREPARATION",
  "EXPEDIEE",
  "LIVREE",
  "ANNULEE",
];

export const updateOrderStatus = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!VALID_STATUSES.includes(status)) {
    throw new AppError("Statut invalide.", 422);
  }

  const order = await prisma.order.findUnique({
    where: { id },
    include: { product: { select: { nom: true } } },
  });
  if (!order) throw new AppError("Commande introuvable.", 404);

  const isSeller = order.sellerId === req.user!.userId;
  const isBuyerCancelling = order.buyerId === req.user!.userId && status === "ANNULEE";

  if (!isSeller && !isBuyerCancelling) {
    throw new AppError("Tu n'as pas la permission de modifier cette commande.", 403);
  }

  const updated = await prisma.order.update({ where: { id }, data: { status } });

  const messages: Record<string, string> = {
    ACCEPTEE: `Ta commande pour "${order.product.nom}" a été acceptée.`,
    REFUSEE: `Ta commande pour "${order.product.nom}" a été refusée.`,
    EN_PREPARATION: `Ta commande pour "${order.product.nom}" est en préparation.`,
    EXPEDIEE: `Ta commande pour "${order.product.nom}" a été expédiée.`,
    LIVREE: `Ta commande pour "${order.product.nom}" a été livrée.`,
    ANNULEE: `La commande pour "${order.product.nom}" a été annulée.`,
  };

  // On notifie l'autre partie (si c'est le vendeur qui agit -> notifie l'acheteur, et inversement)
  const notifyUserId = isSeller ? order.buyerId : order.sellerId;
  await createNotification(notifyUserId, "COMMANDE_STATUT", messages[status]);

  res.status(200).json({ success: true, data: updated });
});
