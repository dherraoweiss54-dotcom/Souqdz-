import { Request, Response } from "express";
import prisma from "../config/db";
import { asyncHandler } from "../middleware/error.middleware";

export const listCategories = asyncHandler(async (req: Request, res: Response) => {
  const categories = await prisma.category.findMany({
    where: { parentId: null },
    include: { enfants: true },
    orderBy: { nom: "asc" },
  });

  res.status(200).json({ success: true, data: categories });
});
