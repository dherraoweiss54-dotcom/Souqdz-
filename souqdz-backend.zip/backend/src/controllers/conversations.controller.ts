import { Request, Response } from "express";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";

// ==========================================
// POST /api/conversations/start  { productId }
// Démarre (ou récupère) la conversation entre l'acheteur connecté et le vendeur du produit
// ==========================================
export const startConversation = asyncHandler(async (req: Request, res: Response) => {
  const { productId } = req.body;
  const buyerId = req.user!.userId;

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new AppError("Produit introuvable.", 404);
  if (product.sellerId === buyerId) {
    throw new AppError("Tu ne peux pas discuter avec toi-même.", 400);
  }

  const conversation = await prisma.conversation.upsert({
    where: {
      productId_buyerId_sellerId: {
        productId,
        buyerId,
        sellerId: product.sellerId,
      },
    },
    update: {},
    create: { productId, buyerId, sellerId: product.sellerId },
    include: {
      product: { select: { id: true, nom: true, images: { take: 1, orderBy: { ordre: "asc" } } } },
      buyer: { select: { id: true, prenom: true, nom: true, photo: true } },
      seller: { select: { id: true, prenom: true, nom: true, photo: true } },
    },
  });

  res.status(200).json({ success: true, data: conversation });
});

// ==========================================
// GET /api/conversations  (mes conversations, en tant qu'acheteur ou vendeur)
// ==========================================
export const myConversations = asyncHandler(async (req: Request, res: Response) => {
  const userId = req.user!.userId;

  const conversations = await prisma.conversation.findMany({
    where: { OR: [{ buyerId: userId }, { sellerId: userId }] },
    orderBy: { createdAt: "desc" },
    include: {
      product: { select: { id: true, nom: true, images: { take: 1, orderBy: { ordre: "asc" } } } },
      buyer: { select: { id: true, prenom: true, nom: true, photo: true } },
      seller: { select: { id: true, prenom: true, nom: true, photo: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
  });

  const withUnread = await Promise.all(
    conversations.map(async (c) => {
      const unreadCount = await prisma.message.count({
        where: { conversationId: c.id, isRead: false, senderId: { not: userId } },
      });
      return { ...c, unreadCount, lastMessage: c.messages[0] || null, messages: undefined };
    })
  );

  res.status(200).json({ success: true, data: withUnread });
});

// ==========================================
// GET /api/conversations/:id/messages  (historique d'une conversation)
// ==========================================
export const getMessages = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const userId = req.user!.userId;

  const conversation = await prisma.conversation.findUnique({ where: { id } });
  if (!conversation) throw new AppError("Conversation introuvable.", 404);
  if (conversation.buyerId !== userId && conversation.sellerId !== userId) {
    throw new AppError("Accès non autorisé à cette conversation.", 403);
  }

  const messages = await prisma.message.findMany({
    where: { conversationId: id },
    orderBy: { createdAt: "asc" },
  });

  // Marquer comme lus les messages envoyés par l'autre personne
  await prisma.message.updateMany({
    where: { conversationId: id, senderId: { not: userId }, isRead: false },
    data: { isRead: true },
  });

  res.status(200).json({ success: true, data: messages });
});
