import { Request, Response } from "express";
import { Prisma } from "@prisma/client";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";

// ==========================================
// GET /api/products  (liste publique avec filtres, recherche, tri, pagination)
// ==========================================
export const listProducts = asyncHandler(async (req: Request, res: Response) => {
  const {
    q,               // recherche texte
    categoryId,
    wilaya,
    commune,
    prixMin,
    prixMax,
    etat,             // NEUF | OCCASION
    livraison,        // filtre "livraison disponible" -> LIVRAISON ou LES_DEUX
    sort,             // recent | prix_asc | prix_desc | populaire
    page = "1",
    limit = "20",
  } = req.query as Record<string, string>;

  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const limitNum = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 50);

  const where: Prisma.ProductWhereInput = {
    status: "ACTIVE", // le public ne voit que les annonces actives et validées
  };

  if (q) {
    where.OR = [
      { nom: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
      { seller: { prenom: { contains: q, mode: "insensitive" } } },
      { seller: { nom: { contains: q, mode: "insensitive" } } },
    ];
  }

  if (categoryId) where.categoryId = categoryId;
  if (wilaya) where.wilaya = wilaya;
  if (commune) where.commune = commune;
  if (etat === "NEUF" || etat === "OCCASION") where.etat = etat;

  if (livraison === "true") {
    where.livraison = { in: ["LIVRAISON", "LES_DEUX"] };
  }

  if (prixMin || prixMax) {
    where.prix = {};
    if (prixMin) where.prix.gte = new Prisma.Decimal(prixMin);
    if (prixMax) where.prix.lte = new Prisma.Decimal(prixMax);
  }

  let orderBy: Prisma.ProductOrderByWithRelationInput = { createdAt: "desc" };
  if (sort === "prix_asc") orderBy = { prix: "asc" };
  if (sort === "prix_desc") orderBy = { prix: "desc" };
  if (sort === "populaire") orderBy = { vues: "desc" };
  // "recent" = comportement par défaut (createdAt desc)

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      orderBy,
      skip: (pageNum - 1) * limitNum,
      take: limitNum,
      include: {
        images: { orderBy: { ordre: "asc" }, take: 1 },
        seller: { select: { id: true, prenom: true, nom: true, photo: true } },
        category: { select: { id: true, nom: true } },
        _count: { select: { favorites: true } },
      },
    }),
    prisma.product.count({ where }),
  ]);

  res.status(200).json({
    success: true,
    data: products,
    pagination: {
      page: pageNum,
      limit: limitNum,
      total,
      totalPages: Math.ceil(total / limitNum),
    },
  });
});

// ==========================================
// GET /api/products/:id  (détail public + incrémentation des vues)
// ==========================================
export const getProductById = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  const product = await prisma.product.findUnique({
    where: { id },
    include: {
      images: { orderBy: { ordre: "asc" } },
      category: true,
      seller: {
        select: {
          id: true,
          prenom: true,
          nom: true,
          photo: true,
          wilaya: true,
          isVerified: true,
          createdAt: true,
          _count: { select: { products: true } },
        },
      },
      _count: { select: { favorites: true } },
    },
  });

  if (!product) {
    throw new AppError("Produit introuvable.", 404);
  }

  // On n'incrémente les vues que pour les annonces actives (évite de fausser les stats admin)
  if (product.status === "ACTIVE") {
    await prisma.product.update({ where: { id }, data: { vues: { increment: 1 } } });
  }

  // Le numéro de téléphone du vendeur n'est jamais exposé ici (voir règle "pas d'info sensible")
  res.status(200).json({ success: true, data: product });
});

// ==========================================
// POST /api/products  (créer une annonce — vendeur connecté)
// ==========================================
export const createProduct = asyncHandler(async (req: Request, res: Response) => {
  const {
    nom,
    description,
    prix,
    categoryId,
    etat,
    wilaya,
    commune,
    livraison,
    telephoneVisible,
  } = req.body;

  if (!nom || !description || !prix || !categoryId || !etat || !wilaya || !commune || !livraison) {
    throw new AppError("Tous les champs obligatoires doivent être remplis.", 422);
  }

  const category = await prisma.category.findUnique({ where: { id: categoryId } });
  if (!category) {
    throw new AppError("Catégorie invalide.", 422);
  }

  const files = (req.files as Express.Multer.File[]) || [];

  const product = await prisma.product.create({
    data: {
      sellerId: req.user!.userId,
      nom,
      description,
      prix: new Prisma.Decimal(prix),
      categoryId,
      etat,
      wilaya,
      commune,
      livraison,
      telephoneVisible: telephoneVisible === "true" || telephoneVisible === true,
      // En attente de validation admin par défaut (voir règle "validation obligatoire")
      status: "EN_ATTENTE",
      images: {
        create: files.map((file, index) => ({
          url: `/uploads/products/${file.filename}`,
          ordre: index,
        })),
      },
    },
    include: { images: true },
  });

  res.status(201).json({
    success: true,
    message: "Annonce créée. Elle sera visible après validation par un administrateur.",
    data: product,
  });
});

// ==========================================
// PUT /api/products/:id  (modifier — propriétaire uniquement)
// ==========================================
export const updateProduct = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  const product = await prisma.product.findUnique({ where: { id } });
  if (!product) throw new AppError("Produit introuvable.", 404);
  if (product.sellerId !== req.user!.userId) {
    throw new AppError("Tu ne peux modifier que tes propres annonces.", 403);
  }

  const { nom, description, prix, categoryId, etat, wilaya, commune, livraison, telephoneVisible } =
    req.body;

  const updated = await prisma.product.update({
    where: { id },
    data: {
      ...(nom && { nom }),
      ...(description && { description }),
      ...(prix && { prix: new Prisma.Decimal(prix) }),
      ...(categoryId && { categoryId }),
      ...(etat && { etat }),
      ...(wilaya && { wilaya }),
      ...(commune && { commune }),
      ...(livraison && { livraison }),
      ...(telephoneVisible !== undefined && {
        telephoneVisible: telephoneVisible === "true" || telephoneVisible === true,
      }),
      // Toute modification repasse l'annonce en attente de validation
      status: "EN_ATTENTE",
    },
  });

  res.status(200).json({
    success: true,
    message: "Annonce modifiée. Elle repasse en attente de validation.",
    data: updated,
  });
});

// ==========================================
// DELETE /api/products/:id  (supprimer — propriétaire uniquement)
// ==========================================
export const deleteProduct = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  const product = await prisma.product.findUnique({ where: { id } });
  if (!product) throw new AppError("Produit introuvable.", 404);
  if (product.sellerId !== req.user!.userId) {
    throw new AppError("Tu ne peux supprimer que tes propres annonces.", 403);
  }

  await prisma.product.delete({ where: { id } });

  res.status(200).json({ success: true, message: "Annonce supprimée." });
});

// ==========================================
// PATCH /api/products/:id/status  (marquer vendu / désactiver — propriétaire uniquement)
// ==========================================
export const updateProductStatus = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body; // VENDUE | DESACTIVEE | ACTIVE

  if (!["VENDUE", "DESACTIVEE", "ACTIVE"].includes(status)) {
    throw new AppError("Statut invalide.", 422);
  }

  const product = await prisma.product.findUnique({ where: { id } });
  if (!product) throw new AppError("Produit introuvable.", 404);
  if (product.sellerId !== req.user!.userId) {
    throw new AppError("Action non autorisée.", 403);
  }

  const updated = await prisma.product.update({ where: { id }, data: { status } });

  res.status(200).json({ success: true, data: updated });
});

// ==========================================
// GET /api/products/mine/list  (mes annonces — vendeur connecté)
// ==========================================
export const myProducts = asyncHandler(async (req: Request, res: Response) => {
  const products = await prisma.product.findMany({
    where: { sellerId: req.user!.userId },
    orderBy: { createdAt: "desc" },
    include: {
      images: { take: 1, orderBy: { ordre: "asc" } },
      _count: { select: { favorites: true, orders: true } },
    },
  });

  res.status(200).json({ success: true, data: products });
});

// ==========================================
// GET /api/products/mine/stats  (statistiques dashboard vendeur)
// ==========================================
export const sellerStats = asyncHandler(async (req: Request, res: Response) => {
  const sellerId = req.user!.userId;

  const [totalAnnonces, annoncesActives, totalVues, totalFavoris, totalCommandes, ventes] =
    await Promise.all([
      prisma.product.count({ where: { sellerId } }),
      prisma.product.count({ where: { sellerId, status: "ACTIVE" } }),
      prisma.product.aggregate({ where: { sellerId }, _sum: { vues: true } }),
      prisma.favorite.count({ where: { product: { sellerId } } }),
      prisma.order.count({ where: { sellerId } }),
      prisma.product.count({ where: { sellerId, status: "VENDUE" } }),
    ]);

  res.status(200).json({
    success: true,
    data: {
      totalAnnonces,
      annoncesActives,
      totalVues: totalVues._sum.vues || 0,
      totalFavoris,
      totalCommandes,
      ventes,
    },
  });
});
