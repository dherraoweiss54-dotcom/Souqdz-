import { Request, Response } from "express";
import prisma from "../config/db";
import { hashPassword, comparePassword } from "../utils/password";
import { signToken } from "../utils/jwt";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";

// Retourne l'utilisateur sans le hash du mot de passe
function sanitizeUser(user: any) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

export const register = asyncHandler(async (req: Request, res: Response) => {
  const { prenom, nom, email, telephone, password, wilaya, commune, role } = req.body;

  const existingEmail = await prisma.user.findUnique({ where: { email } });
  if (existingEmail) {
    throw new AppError("Cet email est déjà utilisé.", 409);
  }

  const existingPhone = await prisma.user.findUnique({ where: { telephone } });
  if (existingPhone) {
    throw new AppError("Ce numéro de téléphone est déjà utilisé.", 409);
  }

  const passwordHash = await hashPassword(password);

  const user = await prisma.user.create({
    data: {
      prenom,
      nom,
      email,
      telephone,
      passwordHash,
      wilaya,
      commune,
      // Par défaut, un compte est BUYER. Il peut ensuite devenir vendeur.
      role: role === "SELLER" ? "SELLER" : "BUYER",
    },
  });

  const token = signToken({ userId: user.id, role: user.role });

  res.status(201).json({
    success: true,
    message: "Compte créé avec succès.",
    data: { user: sanitizeUser(user), token },
  });
});

export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    throw new AppError("Email ou mot de passe incorrect.", 401);
  }

  const isValid = await comparePassword(password, user.passwordHash);
  if (!isValid) {
    throw new AppError("Email ou mot de passe incorrect.", 401);
  }

  if (user.isSuspended) {
    throw new AppError("Ton compte a été suspendu. Contacte le support.", 403);
  }

  const token = signToken({ userId: user.id, role: user.role });

  res.status(200).json({
    success: true,
    message: "Connexion réussie.",
    data: { user: sanitizeUser(user), token },
  });
});

export const me = asyncHandler(async (req: Request, res: Response) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.userId } });
  if (!user) {
    throw new AppError("Utilisateur introuvable.", 404);
  }
  res.status(200).json({ success: true, data: { user: sanitizeUser(user) } });
});

// Permet à un acheteur de devenir vendeur (pas besoin de créer un 2e compte)
export const becomeSeller = asyncHandler(async (req: Request, res: Response) => {
  const user = await prisma.user.update({
    where: { id: req.user!.userId },
    data: { role: "SELLER" },
  });
  res.status(200).json({
    success: true,
    message: "Tu es maintenant vendeur sur SouqDZ.",
    data: { user: sanitizeUser(user) },
  });
});
