import { Request, Response } from "express";
import prisma from "../config/db";
import { AppError } from "../utils/AppError";
import { asyncHandler } from "../middleware/error.middleware";
import { createNotification } from "../services/notification.service";
import { logAdminAction } from "../services/adminLog.service";

// ==========================================
// GET /api/admin/dashboard  (statistiques globales)
// ==========================================
export const dashboard = asyncHandler(async (req: Request, res: Response) => {
  const [
    totalUtilisateurs,
    totalVendeurs,
    totalProduits,
    produitsEnAttente,
    totalCommandes,
    totalSignalements,
    produitsSupprimes,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { role: "SELLER" } }),
    prisma.product.count(),
    prisma.product.count({ where: { status: "EN_ATTENTE" } }),
    prisma.order.count(),
    prisma.report.count({ where: { status: { not: "RESOLU" } } }),
    prisma.adminAction.count({ where: { action: "DELETE_PRODUCT" } }),
  ]);

  res.status(200).json({
    success: true,
    data: {
      totalUtilisateurs,
      totalVendeurs,
      totalProduits,
      produitsEnAttente,
      totalCommandes,
      totalSignalements,
      produitsSupprimes,
    },
  });
});

// ==========================================
// GESTION UTILISATEURS
// ==========================================

// GET /api/admin/users
export const listUsers = asyncHandler(async (req: Request, res: Response) => {
  const { q, role } = req.query as Record<string, string>;

  const users = await prisma.user.findMany({
    where: {
      ...(role && { role: role as any }),
      ...(q && {
        OR: [
          { prenom: { contains: q, mode: "insensitive" } },
          { nom: { contains: q, mode: "insensitive" } },
          { email: { contains: q, mode: "insensitive" } },
        ],
      }),
    },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, prenom: true, nom: true, email: true, telephone: true,
      role: true, wilaya: true, isSuspended: true, isVerified: true, createdAt: true,
      _count: { select: { products: true } },
    },
  });

  res.status(200).json({ success: true, data: users });
});

// GET /api/admin/users/:id  (détail + ses annonces)
export const getUserDetail = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const user = await prisma.user.findUnique({
    where: { id },
    include: {
      products: { orderBy: { createdAt: "desc" } },
    },
  });
  if (!user) throw new AppError("Utilisateur introuvable.", 404);
  const { passwordHash, ...safeUser } = user;
  res.status(200).json({ success: true, data: safeUser });
});

// PATCH /api/admin/users/:id/suspend
export const suspendUser = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const user = await prisma.user.update({ where: { id }, data: { isSuspended: true } });
  await logAdminAction(req.user!.userId, "SUSPEND_USER", "User", id);
  res.status(200).json({ success: true, message: "Utilisateur suspendu.", data: { id: user.id } });
});

// PATCH /api/admin/users/:id/reactivate
export const reactivateUser = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const user = await prisma.user.update({ where: { id }, data: { isSuspended: false } });
  await logAdminAction(req.user!.userId, "REACTIVATE_USER", "User", id);
  res.status(200).json({ success: true, message: "Utilisateur réactivé.", data: { id: user.id } });
});

// DELETE /api/admin/users/:id
export const deleteUser = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  await prisma.user.delete({ where: { id } });
  await logAdminAction(req.user!.userId, "DELETE_USER", "User", id);
  res.status(200).json({ success: true, message: "Utilisateur supprimé." });
});

// ==========================================
// GESTION PRODUITS
// ==========================================

// GET /api/admin/products?status=EN_ATTENTE
export const listProductsAdmin = asyncHandler(async (req: Request, res: Response) => {
  const { status } = req.query as { status?: string };

  const products = await prisma.product.findMany({
    where: status ? { status: status as any } : undefined,
    orderBy: { createdAt: "desc" },
    include: {
      images: { take: 1, orderBy: { ordre: "asc" } },
      seller: { select: { id: true, prenom: true, nom: true, email: true } },
      category: { select: { nom: true } },
    },
  });

  res.status(200).json({ success: true, data: products });
});

// PATCH /api/admin/products/:id/approve
export const approveProduct = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const product = await prisma.product.update({ where: { id }, data: { status: "ACTIVE" } });
  await logAdminAction(req.user!.userId, "APPROVE_PRODUCT", "Product", id);
  await createNotification(product.sellerId, "PRODUIT_APPROUVE", `Ton annonce "${product.nom}" a été approuvée.`);
  res.status(200).json({ success: true, data: product });
});

// PATCH /api/admin/products/:id/reject
export const rejectProduct = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { raison } = req.body;
  const product = await prisma.product.update({ where: { id }, data: { status: "DESACTIVEE" } });
  await logAdminAction(req.user!.userId, "REJECT_PRODUCT", "Product", id);
  await createNotification(
    product.sellerId,
    "PRODUIT_REFUSE",
    `Ton annonce "${product.nom}" a été refusée.${raison ? " Raison: " + raison : ""}`
  );
  res.status(200).json({ success: true, data: product });
});

// PATCH /api/admin/products/:id/suspend
export const suspendProductAdmin = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const product = await prisma.product.update({ where: { id }, data: { status: "DESACTIVEE" } });
  await logAdminAction(req.user!.userId, "SUSPEND_PRODUCT", "Product", id);
  res.status(200).json({ success: true, data: product });
});

// DELETE /api/admin/products/:id
export const deleteProductAdmin = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  await prisma.product.delete({ where: { id } });
  await logAdminAction(req.user!.userId, "DELETE_PRODUCT", "Product", id);
  res.status(200).json({ success: true, message: "Produit supprimé." });
});
