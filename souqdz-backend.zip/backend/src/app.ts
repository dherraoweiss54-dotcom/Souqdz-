import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import path from "path";
import { env } from "./config/env";
import { errorHandler } from "./middleware/error.middleware";

import authRoutes from "./routes/auth.routes";
import miscRoutes from "./routes/misc.routes";
import categoriesRoutes from "./routes/categories.routes";
import productsRoutes from "./routes/products.routes";
import favoritesRoutes from "./routes/favorites.routes";
import ordersRoutes from "./routes/orders.routes";
import notificationsRoutes from "./routes/notifications.routes";
import conversationsRoutes from "./routes/conversations.routes";
import reportsRoutes from "./routes/reports.routes";
import adminRoutes from "./routes/admin.routes";

const app = express();

// Sécurité de base (en-têtes HTTP)
app.use(helmet());

// CORS : seul le frontend autorisé peut appeler l'API
app.use(
  cors({
    origin: env.frontendUrl,
    credentials: true,
  })
);

// Parsing du JSON envoyé par le frontend
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

// Logs des requêtes (utile en développement)
if (env.nodeEnv === "development") {
  app.use(morgan("dev"));
}

// Fichiers statiques (images uploadées)
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

// Route de santé (pour vérifier que le serveur tourne)
app.get("/api/health", (req, res) => {
  res.json({ success: true, message: "SouqDZ API opérationnelle." });
});

// Routes de l'application
app.use("/api/auth", authRoutes);
app.use("/api/categories", categoriesRoutes);
app.use("/api/products", productsRoutes);
app.use("/api/favorites", favoritesRoutes);
app.use("/api/orders", ordersRoutes);
app.use("/api/notifications", notificationsRoutes);
app.use("/api/conversations", conversationsRoutes);
app.use("/api/reports", reportsRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api", miscRoutes);

// Route 404 pour tout ce qui n'existe pas
app.use((req, res) => {
  res.status(404).json({ success: false, message: "Route introuvable." });
});

// Gestionnaire d'erreurs centralisé (toujours en dernier)
app.use(errorHandler);

export default app;
