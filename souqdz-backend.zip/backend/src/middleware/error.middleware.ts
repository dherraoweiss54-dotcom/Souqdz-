import { Request, Response, NextFunction } from "express";
import { AppError } from "../utils/AppError";

// Ce middleware doit être ajouté en DERNIER dans app.ts,
// après toutes les routes, pour capturer toute erreur passée via next(err).
export function errorHandler(
  err: unknown,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction
) {
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
    });
  }

  console.error("Erreur non gérée:", err);

  return res.status(500).json({
    success: false,
    message: "Une erreur interne est survenue. Réessaie plus tard.",
  });
}

// Wrapper pour éviter les try/catch répétés dans chaque controller.
// Utilisation : router.post("/", asyncHandler(controllerFn))
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<any>
) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}
