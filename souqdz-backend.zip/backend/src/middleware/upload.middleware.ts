import multer from "multer";
import path from "path";
import fs from "fs";
import { Request } from "express";
import { env } from "../config/env";
import { AppError } from "../utils/AppError";

const uploadDir = path.join(__dirname, "..", "..", "uploads", "products");

// Créer le dossier s'il n'existe pas
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `product-${uniqueSuffix}${ext}`);
  },
});

function fileFilter(req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) {
  const allowedTypes = ["image/jpeg", "image/png", "image/webp", "image/jpg"];
  if (!allowedTypes.includes(file.mimetype)) {
    return cb(new AppError("Seules les images JPEG, PNG ou WebP sont autorisées.", 422) as any);
  }
  cb(null, true);
}

export const uploadProductImages = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: env.maxFileSizeMb * 1024 * 1024,
    files: env.maxProductImages,
  },
}).array("images", env.maxProductImages);
