import { Request, Response, NextFunction } from "express";
import { verifyToken, JwtPayload } from "../utils/jwt";
import { AppError } from "../utils/AppError";
import prisma from "../config/db";

// On étend le type Request d'Express pour y ajouter l'utilisateur connecté
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

// Vérifie que l'utilisateur est connecté (token JWT valide dans le header Authorization)
export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new AppError("Non authentifié. Merci de te connecter.", 401);
    }

    const token = authHeader.split(" ")[1];
    const payload = verifyToken(token);

    // On vérifie que l'utilisateur existe toujours et n'est pas suspendu
    const user = await prisma.user.findUnique({ where: { id: payload.userId } });

    if (!user) {
      throw new AppError("Utilisateur introuvable.", 401);
    }
    if (user.isSuspended) {
      throw new AppError("Ton compte a été suspendu.", 403);
    }

    req.user = payload;
    next();
  } catch (err) {
    if (err instanceof AppError) return next(err);
    next(new AppError("Token invalide ou expiré.", 401));
  }
}

// Vérifie que l'utilisateur connecté a l'un des rôles autorisés
export function requireRole(...roles: Array<"BUYER" | "SELLER" | "ADMIN">) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(
        new AppError("Tu n'as pas la permission d'accéder à cette ressource.", 403)
      );
    }
    next();
  };
}
