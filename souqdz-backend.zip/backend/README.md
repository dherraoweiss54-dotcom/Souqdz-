# SouqDZ Backend — Phase 1 (Base + Authentification)

## ما تحتاجه قبل البداية

1. **Node.js** (نسخة 18 أو أحدث) — حمّلها من https://nodejs.org
2. **PostgreSQL** مثبت محلياً، أو حساب مجاني على https://neon.tech أو https://railway.app (أسهل للمبتدئين — يعطيك DATABASE_URL جاهز بدون تثبيت شيء محلياً)

تأكد أن Node مثبت بكتابة في Terminal:
```
node -v
npm -v
```

## خطوات التشغيل

### 1. افتح Terminal داخل مجلد backend

```
cd souqdz/backend
```

### 2. ثبّت كل المكتبات

```
npm install
```

### 3. جهّز ملف .env

انسخ الملف `.env.example` وسمّه `.env`:

```
cp .env.example .env
```

افتح `.env` وعدّل السطر `DATABASE_URL` بمعلومات قاعدة بياناتك.

مثال إذا PostgreSQL مثبت محلياً:
```
DATABASE_URL="postgresql://postgres:motdepasse@localhost:5432/souqdz"
```

مثال إذا استعملت Neon أو Railway (انسخ الرابط اللي يعطوك إياه):
```
DATABASE_URL="postgresql://user:pass@ep-xxxx.neon.tech/souqdz"
```

غيّر أيضاً `JWT_SECRET` بأي نص طويل عشوائي (مثلاً 40 حرف/رقم).

### 4. أنشئ الجداول في قاعدة البيانات

```
npx prisma migrate dev --name init
```

هذا الأمر يقرأ ملف `prisma/schema.prisma` وينشئ كل الجداول تلقائياً.

### 5. أضف البيانات الأساسية (catégories + compte admin)

```
npm run seed
```

### 6. شغّل السيرفر

```
npm run dev
```

إذا كل شيء تمام، راح تشوف في Terminal:
```
🚀 SouqDZ API démarrée sur http://localhost:5000
```

## اختبار الـ API

افتح المتصفح على:
```
http://localhost:5000/api/health
```
لازم يرجع لك: `{"success":true,"message":"SouqDZ API opérationnelle."}`

### تسجيل حساب جديد (Register)

استعمل Postman أو Thunder Client (extension VS Code) أو حتى curl:

```
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "prenom": "Ahmed",
    "nom": "Benali",
    "email": "ahmed@test.dz",
    "telephone": "0551234567",
    "password": "motdepasse123",
    "wilaya": "Alger",
    "commune": "Bab Ezzouar"
  }'
```

راح يرجعلك `token` — احتفظ بيه، تحتاجه لكل طلب محمي.

### تسجيل الدخول (Login)

```
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "ahmed@test.dz", "password": "motdepasse123"}'
```

### معرفة معلومات المستخدم المتصل (Route محمية)

```
curl http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer TOKEN_ICI"
```

### مشاهدة قاعدة البيانات بصرياً (اختياري لكن مفيد جداً)

```
npx prisma studio
```
يفتح واجهة في المتصفح تقدر تشوف بيها كل الجداول والبيانات.

## ما تم إنجازه في هذه المرحلة

- ✅ هيكلة المشروع كاملة (config, middleware, routes, controllers)
- ✅ Prisma schema بكل الجداول (users, products, categories, favorites, conversations, messages, orders, notifications, reviews, reports, admin_actions)
- ✅ تسجيل حساب (Register) مع validation
- ✅ تسجيل الدخول (Login) مع JWT
- ✅ Middleware حماية الروابط (requireAuth) و الأدوار (requireRole)
- ✅ Password hashing بـ bcrypt
- ✅ قائمة الـ 58 ولاية جزائرية جاهزة عبر `/api/wilayas`
- ✅ Seed تلقائي للكاتيغوريات و compte admin

## المرحلة الجاية

المرحلة 2: APIs المنتجات (إنشاء، بحث، فلاتر، تفاصيل) + الفافوري.

قولي "نبدأ المرحلة 2" ونكملو.
