import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const CATEGORIES = [
  "Téléphones",
  "Informatique",
  "Électronique",
  "Mode",
  "Maison",
  "Véhicules",
  "Électroménager",
  "Sport",
  "Jeux vidéo",
  "Beauté",
  "Services",
  "Autres",
];

async function main() {
  console.log("🌱 Démarrage du seed...");

  // 1. Créer les catégories principales (si elles n'existent pas déjà)
  for (const nom of CATEGORIES) {
    const existing = await prisma.category.findFirst({ where: { nom } });
    if (!existing) {
      await prisma.category.create({ data: { nom } });
      console.log(`  ✔ Catégorie créée: ${nom}`);
    }
  }

  // 2. Créer un compte admin par défaut (à changer après la première connexion !)
  const adminEmail = "admin@souqdz.dz";
  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });

  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash("Admin123!", 10);
    await prisma.user.create({
      data: {
        prenom: "Admin",
        nom: "SouqDZ",
        email: adminEmail,
        telephone: "0500000000",
        passwordHash,
        role: "ADMIN",
        wilaya: "Alger",
        commune: "Alger Centre",
        isVerified: true,
      },
    });
    console.log("  ✔ Compte admin créé -> email: admin@souqdz.dz / mot de passe: Admin123!");
    console.log("    ⚠️  Change ce mot de passe immédiatement après ta première connexion.");
  }

  console.log("✅ Seed terminé.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
